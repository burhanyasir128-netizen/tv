# ========================================================
# Tamasha OTT Android App - ProGuard / R8 Obfuscation Rules
# ========================================================

# Optimization & Obfuscation
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose

# Strip production logs and debugging statements
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}

# Preserve Native App Activity
-keep public class com.tamasha.ott.MainActivity {
    public *;
}

# Preserve AndroidX WebKit AssetLoader
-keep class androidx.webkit.** { *; }

# Strip source file attributes and line numbers in release builds
-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable
